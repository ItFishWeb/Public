<?php
 include 'sendEmail.php';
?>

<!DOCTYPE html>
<html lang="pl-en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

      <!-- Bootstrap CSS -->
      <link href="css/bootstrap.min.css" rel="stylesheet">

      <!-- FONTELLO -->
      <link rel="stylesheet" href="css/style.css">
      <link rel="stylesheet" href="css/fontello.css">
      <!--Google Fonts-->
      <link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
      <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,300;1,900&display=swap" rel="stylesheet">

      <link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
      <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Montserrat:ital,wght@0,300;1,900&display=swap" rel="stylesheet">

      <!-- Modernizr -->
      <script src="js/modernizr-custom.js"></script>

      <!-- ScrollReveal -->
      <script src="js/ScrollReveal.js"></script>

      <link rel="icon" type="image/x-icon" href="img/Logo.png">
    <title>NicoClean Usługi Sprzątające</title>
  
    <style>
      
    </style>
  
</head>
<body>

  <div id="preloader">
    
  </div>

  <div class="container-fluid" style="padding: 0 !important;">
<header>
    <h1 class="semanticHeader" style="display: none;">NicoClean Usługi sprzątające</h1>
  <nav class="navbar fixed-top navbar-expand-lg navbar-dark p-md-3" style="  font-family: 'Bebas Neue', cursive;
    font-size: 1.5rem;"> <h1 class="semanticHeader" style="display: none;">Nawigacja Górna</h1>
      <div class="container">
        <a class="navbar-brand" href="#">NicoClean</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <div class="mx-auto"></div>
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link text-white" href="#stronaGlowna">STRONA GŁÓWNA</a>
            </li>
            <li class="nav-item">
              <a class="nav-link text-white" href="#oNas">O NAS</a>
            </li>
            <li class="nav-item">
              <a class="nav-link text-white" href="#oferta">OFERTA</a>
            </li>
            <li class="nav-item">
              <a class="nav-link text-white" href="#kontakt">KONTAKT</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
</header>

<div class="container-fluid" id="stronaGlowna" style="background-image: url('img/banerHome2.1.png');">
  <div class="content text-end d-none d-xl-block">
    <a href="#kontakt" style="text-decoration: none;color:white;"><button class="btnHome" type="button">ZAMÓW</br>SPRZĄTANIE</button></a>
  </div>
</div>
<div style="height:70px" id="oNas"></div>
<section>
    <h1 class="semanticHeader" style="display: none;">O nas</h1>
    <div class="container" style="margin-top: 2%;">
    <section>
      <header id="CzymSieZajmujemy">
          <h1 class="mainHeading load-hidden">CZYM SIĘ <span class="spanMainHeading">ZAJMUJEMY ?</span></h1>
          <div class="col-2 col-xl-2 mainBorder" style="border-bottom: 4px solid #208BE3;"></div>
          <p class="czymSieZajmujemyP">Potrzebujesz zadbać o czystość w Twoim otoczeniu? My zadbamy o to kompleksowo. Pierzemy tapicerkę meblową, samochodową oraz dywany i wykładziny. Ozonujemy pomieszczenia. Sprzątamy mieszkania i biura.</p>
 </header>
 <div class="row" id="rowCzymSieZajmujemy">
  <div class="col-6 col-md-4 col-lg-4 justify-content-mid" style="height:fit-content;margin-bottom: 2%;">
        <section id="pranieMeblowe">
          <header>
            <h1 class="semanticHeader" style="display: none;">PRANIE TAPICERKI MEBLOWEJ</h1>
          </header>
          <div class="img-thumbnail text-center" id="pojemnikCzymSieZajmujemy">
            <img class="czymSieZajmujemyImg" src="img/ptm.jpg" class="rounded mx-auto d-block" style="width: 100%;height:auto">

            <p class="czymSieZajmujemyH3">PRANIE TAPICERKI MEBLOWEJ</p>
            <div class="text-center">
              <button class="btn btn-primary" id="czymSieZajmujemyButtons" style="background-color:#208BE3;" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasWithBothOptionsM" aria-controls="offcanvasWithBothOptionsM">
                ZOBACZ SZCZEGÓŁY
              </button>
              </div>

              <div class="offcanvas offcanvas-start" style="background-color: #444444;width:90%;color:white;font-family: 'Bebas Neue', cursive;" data-bs-scroll="true" tabindex="-1" id="offcanvasWithBothOptionsM" aria-labelledby="offcanvasWithBothOptionsLabel">
                  <div class="text-end" style="background-color:#208BE3;">
                  <p class="offcanvas-title" id="offcanvasWithBothOptionsLabel" style="float:left;"><p style="float: left;text-align:center;font-size:1.2rem;margin-left:45%;padding-top:2px;">PRANIE TAPICERKI MEBLOWEJ</p><button type="button" class="btn-close text-reset" style="" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                  </p>
                  </div>
                  <div class="offcanvas-body" style="word-wrap:break-word">
    
                    <div class="row" style="height: 600px;">
                      <div class="col-12 col-lg-6" style="margin-top: 1%;">
                        <iframe width="100%" height="415" src="https://www.youtube.com/embed/siw9LZFem4c" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

                      </div>
                      <div class="col-12 col-lg-6" style="color:white;">
                        <div class="paragrafPTM" style="text-align: center;" ><p>Idą goście, a na narożniku są paskudne plamy? Jeżeli nie masz czasu się tym zająć, zadzwoń do nas, a my Cię wyręczymy. Dowiedz się więcej i skorzystaj z przycisków poniżej.</p></div>
                        <div class="accordion" id="accordionExample" style="background-color: #444444;">
                          <div class="accordion-item" style="background-color: #444444;">
                            <h2 class="accordion-header" style="text-align: center;" id="headingOne">
                              <button class="accordion-button" style="" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                              <div class="text-center">Jak przebiega czyszczenie ?</div>
                              </button>
                            </h2>
                            <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                              <div class="accordion-body">
                                <div class="row" style="padding: 0 !important;font-size:0.8rem;">
                            <div class="col-12" style="padding: 0 !important;margin: 0 !important;">
                                <ul style="list-style-type: none;padding: 0 !important;font-family: 'Montserrat', sans-serif;word-break: break-all;">
                                  <li style="font-size: 1rem;margin-bottom:2%; font-family: 'Bebas Neue', cursive;"><i class="icon-ok"style="color:green;visibility:hidden;"></i>Jak przebiega czyszczenie ?</li>
                                  <li><i class="icon-ok"style=""></i>Odkurzanie tapicerki</li>
                                  <li><i class="icon-ok"></i>Dobieranie odpowiedniego rodzaju chemii</li>
                                  <li><i class="icon-ok"></i>Nakładanie detergentu do wstępnego rozpuszczenia brudu</li>
                                  <li><i class="icon-ok"></i>Odplamianie</li>
                                  <li><i class="icon-ok"></i>Płukanie i neutralizacja chemii do rozpuszczania brudu</li>
                                </ul>
                              </div>
                              <div class="col-12" style="padding: 0 !important;margin: 0 !important;">
                                <ul style="list-style-type: none;padding:0 !important;font-family: 'Montserrat', sans-serif;word-break: break-all;">
                                  <li style="font-size: 1rem;margin-bottom:2%;margin-left:-3%;font-family: 'Bebas Neue', cursive;"><i class="icon-ok"style="color:green;visibility:hidden;"></i>Warto wiedzieć !</li>
                                  <li><i class="icon-ok"></i>Tapicerka schnie od kilku do kilkunastu godzin</li>
                                  <li><i class="icon-ok"></i>Podczas prania zabijamy bakterie i roztocza</li>
                                  <li><i class="icon-ok"></i>Nasza chemia jest nieszkodliwa dla zwierząt i dzieci</li>
                                </ul>
                              </div>
                              </div>
                              </div>
                            </div>
                          </div>
                          <div class="accordion-item">
                            <h2 class="accordion-header" id="headingTwo">
                              <button class="accordion-button collapsed"   type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                Pytanie i odpowiedzi
                              </button>
                            </h2>
                            <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                              <div class="accordion-body">
                                <div class="containerP">
                                   <p class="paragrafContainerP">1. Ile wynosi czas schnięcia mebli i dywanów po praniu?</p>
                                <div class="overlayP" >
                                <div class="textP"><p class="paragraftextP">1. Jest to kwestia materiału, z którego wykonane są włókna. Czas schnięcia zależy również od wilgotności  pomieszczenia i wynosi od kilku do kilkunastu godzin.</p></div>
                                </div>
                                </div>
                                <div class="containerP">
                                  <p class="paragrafContainerP">2. Czy pranie zabija wirusy i bakterie?</p>
                                <div class="overlayP" >
                                <div class="textP"><p class="paragraftextP">2. Tak, pranie ekstrakcyjne trafia głeboko w tapicerkę, czyszcząc ją, zabijając roztocza bakterie oraz wirusy. Wyciąga również brud i kurz.</p></div>
                                </div>
                                </div>
                                <div class="containerP">
                                  <p class="paragrafContainerP">3. Jak odbywa się usługa prania tapicerki?</p>
                                <div class="overlayP" >
                                <div class="textP"><p class="paragraftextP">3. Jest to kwestia materiału, z którego wykonane są włókna. Czas schnięcia zależy również od wilgotności  pomieszczenia i wynosi od kilku do kilkunastu godzin.</p></div>
                                </div>
                                </div>
                                <div class="containerP" style="height: 65px;">
                                  <p class="paragrafContainerP">4. Co jest wymagane, aby usługa się odbyła?</p>
                                <div class="overlayP" >
                                <div class="textP"><p class="paragraftextP">4. Najbardziej wymagany jest dostęp do prądu i cepłej wody. Resztą zajmiemy się sami :)</p></div>
                                </div>
                                </div>
                                <div class="containerP" style="height:115px;">
                                  <p class="paragrafContainerP">5. Czy wszystkie plamy znikną?</p>
                                <div class="overlayP" >
                                <div class="textP"><p class="paragraftextP">5. Niestety nie możemy gwarantować usunięcia wszystkich plam. Szczególnie uciążliwe są stare plamy, plamy z krwi, plamy powstałe w wyniku zapierania tapicerki. Jednakże w 95% przypadków udaję się usunąć wszystkie.</p></div>
                                </div>
                                </div>
                               </div>
                              </div>
                            </div>
                          <div class="accordion-item">
                            <h2 class="accordion-header" id="headingThree">
                              <button class="accordion-button collapsed"   type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                Realizacje
                              </button>
                            </h2>
                            <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                              <div class="accordion-body">
                                <div class="rowL">
                                  <div class="columnL">
                                    <img src="img/czystakanapadwa.jpg" style="width:100%" onclick="openModal();currentSlide(1)" class="hover-shadowL cursorL">
                                  </div>
                                  <div class="columnL">
                                    <img src="img/czystakanapa.jpg" style="width:100%" onclick="openModal();currentSlide(2)" class="hover-shadowL cursorL">
                                  </div>
                                  <div class="columnL">
                                    <img src="img/czystakanapadwa.jpg" style="width:100%" onclick="openModal();currentSlide(3)" class="hover-shadowL cursorL">
                                  </div>
                                  <div class="columnL">
                                    <img src="img/czystakanapa.jpg" style="width:100%" onclick="openModal();currentSlide(4)" class="hover-shadowL cursorL">
                                  </div>
                                </div>
                                
                                <div id="myModalL" class="modalL">
                                  <span class="closeL cursorL" onclick="closeModal()">&times;</span>
                                  <div class="modal-contentL">
                                
                                    <div class="mySlidesL">
                                      <div class="numbertextL">1 / 4</div>
                                      <img src="img/czystakanapadwa.jpg" style="width:100%;height:50%;">
                                    </div>
                                
                                   <div class="mySlidesL">
                                      <div class="numbertextL">2 / 4</div>
                                      <img src="img/czystakanapa.jpg" style="width:100%;height:auto;">
                                    </div>
                                
                                    <div class="mySlidesL">
                                      <div class="numbertextL">3 / 4</div>
                                      <img src="img/czystakanapadwa.jpg" style="width:100%;height:auto;">
                                    </div>
                                    
                                   <div class="mySlidesL">
                                      <div class="numbertextL">4 / 4</div>
                                      <img src="img/czystakanapa.jpg" style="width:100%;height:auto;">
                                    </div>
                                    
                                    <a class="prevL" onclick="plusSlides(-1)">&#10094;</a>
                                    <a class="nextL" onclick="plusSlides(1)">&#10095;</a>
                                
                                    <div class="caption-containerL">
                                      <p id="captionL"></p>
                                    </div>
                                    <div class="columnL">
                                      <img class="demoL cursorL" src="img/czystakanapadwa.jpg" style="width:50%" onclick="currentSlide(1)" alt="Brudna Kanapa Przed">
                                    </div>
                                    <div class="columnL">
                                      <img class="demoL cursorL" src="img/czystakanapa.jpg" style="width:50%" onclick="currentSlide(2)" alt="Czysta Kanapa Po">
                                    </div>
                                    <div class="columnL">
                                      <img class="demoL cursorL" src="img/czystakanapadwa.jpg" style="width:50%" onclick="currentSlide(3)" alt="Brudne Cokolwiek">
                                    </div>
                                    <div class="columnL">
                                      <img class="demoL cursorL" src="img/czystakanapa.jpg" style="width:50%" onclick="currentSlide(4)" alt="Czyste Cokolwiek">
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                              </div>
                          <div class="accordion-item">
                            <h2 class="accordion-header" id="headingFour">
                              <button class="accordion-button collapsed"   type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                Cennik
                              </button>
                            </h2>
                            <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour" data-bs-parent="#accordionExample">
                              <div class="accordion-body">
                                <div class="table-responsive-sm" style="background-color: #444444;">
                                  <table class="table"  style="background-color:#444444;line-height:6px ;height: 100%;font-size:0.8rem;color:white;">
                                    <thead>
                                    </thead>
                                    <tbody>
                                      <tr>
                                        <td>Pranie kanapy lub sofy 2/3-osobowej</td>
                                        <td ><strong>Od 120zł</strong></td>
                                      </tr></br>
                                      <tr>
                                        <td >Narożnik mały (suma boków do 4,5m)</td>
                                        <td><strong>Od 120zł</strong></td>
                                      </tr>
                                      <tr>
                                        <td>Narożnik duży (suma boków pow. 4,5m)</td>
                                        <td><strong>Od 160zł</strong></td>
                                      </tr>
                                      <tr>
                                        <td>Narożnik w kształcie U</td>
                                        <td><strong>Od 180zł</strong></td>
                                      </tr>
                                      <tr>
                                        <td>Poduszka tapicerowana</td>
                                        <td><strong>Od 10zł</strong></td>
                                      </tr>
                                      <tr>
                                        <td>Fotel</td>
                                        <td><strong>Od 25zł</strong></td>
                                      </tr>
                                      <tr>
                                        <td>Krzesło/Krzesło tapicerowane</td>
                                        <td><strong>Od 10zł</strong></td>
                                      </tr>
                                      <tr>
                                        <td>Pufy</td>
                                        <td><strong>Od 20zł</strong></td>
                                      </tr>
                                      <tr>
                                        <td>Materac jednostronnie/dwustronnie</td>
                                        <td><strong>Od 80zł</strong></td>
                                      </tr>
                                      <tr>
                                        <td>Gondola/Wózek/Fotelik samochodowy</td>
                                        <td><strong>Od 50zł</strong></td>
                                      </tr>
                                    </tbody>
                                  </table>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="text-center"><a href="#kontakt" style="text-decoration: none;color:white;">
                      <button class="jebanyPrzyciskWPierdolonejOffCanvie" style="">ZAMÓW SPRZĄTANIE</button></a></div>
                    </div>
                    </div>
                    </div>
                    </div>

        </section>
  </div>

  <div class="col-6 col-md-4 col-lg-4 justify-content-mid" style="height:fit-content;margin-bottom: 2%;">
        <section id="pranieDywanow">
          <header>
            <h1 class="semanticHeader" style="display: none;">PRANIE DYWANÓW I WYKŁADZIN</h1>
          </header>
          <div class="img-thumbnail text-center" id="pojemnikCzymSieZajmujemy">
            <img class="czymSieZajmujemyImg" src="img/ptmid.jpg" style="width: 100%;height:auto;">
            <p class="czymSieZajmujemyH3">PRANIE DYWANÓW I WYKŁADZIN</p>
            <div class="text-center">
              <button class="btn btn-primary" id="czymSieZajmujemyButtons" style="background-color:#208BE3;" type="button"data-bs-toggle="offcanvas" data-bs-target="#offcanvasWithBothOptionsW" aria-controls="offcanvasWithBothOptionsW">
                ZOBACZ SZCZEGÓŁY
              </button>
              </div>
              <div class="offcanvas offcanvas-end"  style="background-color: #444444;width:90%;color:white;font-family: 'Bebas Neue', cursive;" data-bs-scroll="true" tabindex="-1" id="offcanvasWithBothOptionsW" aria-labelledby="offcanvasWithBothOptionsLabel">
                  <div class="text-end" style="background-color:#208BE3;">
                    <p class="offcanvas-title" id="offcanvasWithBothOptionsLabel" style="float:left;font-size:1rem;"><button type="button" style="width:10%;" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button><p style="float: left;text-align:center;font-size:1.2rem;margin-left:45%;padding-top:2px;">PRANIE DYWANÓW I WYKŁADZIN</p>
                  </p>
                  </div>
                <div class="offcanvas-body" style="word-wrap: break-word;">
                         
                  <div class="row" style="height: 600px;">
                    <div class="col-12 col-lg-6" style="margin-top: 1%;">
                      <iframe width="100%" height="415" src="https://www.youtube.com/embed/siw9LZFem4c" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          
                    </div>
                    <div class="col-12 col-lg-6" style="color:white;">
                      <div class="paragrafPTW" style="text-align: center;" ><p>Jeżeli potrzebujesz gruntownie wyczyścić swój dywan lub wykładzinę napisz do nas. Poniżej znajdziesz informacje związane z usługą.</p></div>
                      <div class="accordion" id="accordionExampleW" style="background-color: #444444;">
                        <div class="accordion-item" style="background-color: #444444;">
                          <h2 class="accordion-header" style="text-align: center;" id="headingOne">
                            <button class="accordion-button" style="" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOneW" aria-expanded="true" aria-controls="collapseOneW">
                            <div class="text-center">Jak przebiega czyszczenie ?</div>
                            </button>
                          </h2>
                          <div id="collapseOneW" class="accordion-collapse collapse show" aria-labelledby="headingOneW" data-bs-parent="#accordionExampleW">
                            <div class="accordion-body">
                              <div class="row" style="padding: 0 !important;font-size:0.8rem;">
                                <div class="col-12 col-lg-6" style="padding: 0 !important;margin: 0 !important;">
                              <ul style="list-style-type: none;padding: 0 !important;font-family: 'Montserrat', sans-serif;word-break: break-all;">
                                <li style="font-size: 1rem;margin-bottom:2%; font-family: 'Bebas Neue', cursive;"><i class="icon-ok"style="color:green;visibility:hidden;"></i>Jak przebiega czyszczenie ?</li>
                                <li><i class="icon-ok"style=""></i>Rozpoznanie materiału</li>
                                <li><i class="icon-ok"></i>Odkurzanie dywanu i podnoszenie runa</li>
                                <li><i class="icon-ok"></i>Nakładanie detergentu do wstępnego rozpuszczenia brudu</li>
                                <li><i class="icon-ok"></i>Wcieranie detergentu przy użyciu delikatnych szczotek</li>
                                <li><i class="icon-ok"></i>Odplamianie</li>
                                <li><i class="icon-ok"></i>Płukanie i neutralizacja chemii</li>
                              </ul>
                            </div>
                            <div class="col-12 col-lg-6" style="padding: 0 !important;margin: 0 !important;">
                              <ul style="list-style-type: none;padding:0 !important;font-family: 'Montserrat', sans-serif;word-break: break-all;">
                                <li style="font-size: 1rem;margin-bottom:2%;margin-left:-3%;font-family: 'Bebas Neue', cursive;"><i class="icon-ok"style="color:green;visibility:hidden;"></i>Warto wiedzieć !</li>
                                <li><i class="icon-ok"></i>Praniem zabijemy nieprzyjemne zapachy, wirusy i bakterie</li>
                                <li><i class="icon-ok"></i>Twój dywan odzyska kolory i będzie przyjemny w dotyku</li>
                                <li><i class="icon-ok"></i>Dzięki naszym metodom podnosimy runo dywanu i wykładziny</li>
                              </ul>
                            </div>
                            </div>
                            </div>
                          </div>
                        </div>
                        <div class="accordion-item">
                          <h2 class="accordion-header" id="headingTwoW">
                            <button class="accordion-button collapsed"   type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwoW" aria-expanded="false" aria-controls="collapseTwoW">
                              Pytanie i odpowiedzi
                            </button>
                          </h2>
                          <div id="collapseTwoW" class="accordion-collapse collapse" aria-labelledby="headingTwoW" data-bs-parent="#accordionExampleW">
                            <div class="accordion-body">
                              <div class="containerPW">
                                 <p class="paragrafContainerPW">1. Ile wynosi czas schnięcia dywanów i wykładziny?</p>
                              <div class="overlayPW" >
                              <div class="textPW"><p class="paragraftextPW">1. Wszystko zależy od materiału z jakiego są wykonane. Dywany z krótkim włosiem schną do kilku godzin, jednakże te z dłuższym włosiem nawet do kilkunastu. Zalecamy zawsze, aby nie korzystać z nich do 12 godzin.</p></div>
                              </div>
                              </div>
                              <div class="containerPW">
                                <p class="paragrafContainerPW">2.	Mój dywan jest mocno zadeptany i brudny, czy wszystkie plamy znikną?</p>
                              <div class="overlayPW" >
                              <div class="textPW"><p class="paragraftextPW">2. Do każdej usługi podchodzimy indywidualnie i dotrzymamy wszelkich starań by usunąć każde zabrudzenie. Niektóre niestety są tak rozległe, że są trudne w usunięciu. Zdeptane runo dywanów podnosimy specjalnymi szczotkami w naszych sprzętach.</p></div>
                              </div>
                              </div>
                              <div class="containerPW">
                                <p class="paragrafContainerPW">3.	Jak odbywa się usługa prania dywanu?</p>
                              <div class="overlayPW" >
                              <div class="textPW"><p class="paragraftextPW">3. Nasi wykwalifikowani pracownicy w dniu usługi skontaktują się przed przyjazdem do Ciebie. W domu poproszą Cię o dostęp do prądu oraz ciepłej wody. Wszystkie meble powinny zostać usunięte z miejsc, w których klient wymaga prania. Resztą zajmujemy się my 😊</p></div>
                              </div>
                              </div>
                              <div class="containerPW" style="height: 65px;">
                                <p class="paragrafContainerPW">4. Czy usuwacie plamy z moczu?</p>
                              <div class="overlayPW" >
                              <div class="textPW"><p class="paragraftextPW">4. Nasze włochate pociechy lubią często nabroić. Niestety celem stają się dywany, po których chodzimy. Tak – usuwamy i neutralizujemy zapachy moczu.</p></div>
                              </div>
                              </div>
                              <div class="containerPW" style="height:115px;">
                                <p class="paragrafContainerPW">5. Z jakiego materiału pierzecie dywany?</p>
                              <div class="overlayPW" >
                              <div class="textPW"><p class="paragraftextPW">5. Pierzemy wszystkie dywany/wykładziny poliestrowe, wełniane, z długim, z krótkim włosiem. Nie zajmujemy się dywanami wiskozowymi i jutowymi.</p></div>
                              </div>
                              </div>
                             </div>
                            </div>
                          </div>
                        <div class="accordion-item">
                          <h2 class="accordion-header" id="headingThreeW">
                            <button class="accordion-button collapsed"   type="button" data-bs-toggle="collapse" data-bs-target="#collapseThreeW" aria-expanded="false" aria-controls="collapseThreeW">
                              Realizacje
                            </button>
                          </h2>
                          <div id="collapseThreeW" class="accordion-collapse collapse" aria-labelledby="headingThreeW" data-bs-parent="#accordionExampleW">
                            <div class="accordion-body">
                              <div class="rowLW">
                                <div class="columnLW">
                                  <img src="img/czystakanapadwa.jpg" style="width:100%" onclick="openModalW();currentSlideW(1)" class="hover-shadowLW cursorLW">
                                </div>
                                <div class="columnLW">
                                  <img src="img/czystakanapa.jpg" style="width:100%" onclick="openModalW();currentSlideW(2)" class="hover-shadowLW cursorLW">
                                </div>
                                <div class="columnLW">
                                  <img src="img/czystakanapadwa.jpg" style="width:100%" onclick="openModalW();currentSlideW(3)" class="hover-shadowLW cursorLW">
                                </div>
                                <div class="columnLW">
                                  <img src="img/czystakanapa.jpg" style="width:100%" onclick="openModalW();currentSlideW(4)" class="hover-shadowLW cursorLW">
                                </div>
                              </div>
                              
                              <div id="myModalLW" class="modalLW">
                                <span class="closeLW cursorLW" onclick="closeModalW()">&times;</span>
                                <div class="modal-contentLW">
                              
                                  <div class="mySlidesLW">
                                    <div class="numbertextLW">1 / 4</div>
                                    <img src="img/czystakanapadwa.jpg" style="width:100%;height:50%;">
                                  </div>
                              
                                 <div class="mySlidesLW">
                                    <div class="numbertextLW">2 / 4</div>
                                    <img src="img/czystakanapa.jpg" style="width:100%;height:auto;">
                                  </div>
                              
                                  <div class="mySlidesLW">
                                    <div class="numbertextLW">3 / 4</div>
                                    <img src="img/czystakanapadwa.jpg" style="width:100%;height:auto;">
                                  </div>
                                  
                                 <div class="mySlidesLW">
                                    <div class="numbertextLW">4 / 4</div>
                                    <img src="img/czystakanapa.jpg" style="width:100%;height:auto;">
                                  </div>
                                  
                                  <a class="prevLW" onclick="plusSlidesW(-1)">&#10094;</a>
                                  <a class="nextLW" onclick="plusSlidesW(1)">&#10095;</a>
                              
                                  <div class="caption-containerLW">
                                    <p id="captionLW"></p>
                                  </div>
                                  <div class="columnLW">
                                    <img class="demoLW cursorLW" src="img/czystakanapadwa.jpg" style="width:50%" onclick="currentSlideW(1)" alt="Brudna Kanapa Przed">
                                  </div>
                                  <div class="columnLW">
                                    <img class="demoLW cursorLW" src="img/czystakanapa.jpg" style="width:50%" onclick="currentSlideW(2)" alt="Czysta Kanapa Po">
                                  </div>
                                  <div class="columnLW">
                                    <img class="demoLW cursorLW" src="img/czystakanapadwa.jpg" style="width:50%" onclick="currentSlideW(3)" alt="Brudne Cokolwiek">
                                  </div>
                                  <div class="columnLW">
                                    <img class="demoLW cursorLW" src="img/czystakanapa.jpg" style="width:50%" onclick="currentSlideW(4)" alt="Czyste Cokolwiek">
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                            </div>
                        <div class="accordion-item">
                          <h2 class="accordion-header" id="headingFourW">
                            <button class="accordion-button collapsed"   type="button" data-bs-toggle="collapse" data-bs-target="#collapseFourW" aria-expanded="false" aria-controls="collapseFourW">
                              Cennik
                            </button>
                          </h2>
                          <div id="collapseFourW" class="accordion-collapse collapse" aria-labelledby="headingFourW" data-bs-parent="#accordionExampleW">
                            <div class="accordion-body">
                              <div class="table-responsive-sm" style="background-color: #444444;">
                                <table class="table"  style="background-color:#444444;line-height:6px ;height: 100%;font-size:0.8rem;color:white;">
                                  <thead>
                                  </thead>
                                  <tbody>
                                    <tr>
                                      <td>Pranie dywanu z krótkim włosiem</td>
                                      <td><strong>Od 10zł/mkw</strong></td>
                                    </tr>
                                    <tr>
                                      <td>Pranie wykładziny</td>
                                      <td><strong>Od 10zł/mkw</strong></td>
                                    </tr>
                                    <tr>
                                      <td>Wycena dla firm</td>
                                      <td><strong>Indywidualna</strong></td>
                                    </tr>
                              </tbody>
                                </table>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="text-center"><a href="#kontakt" style="text-decoration: none;color:white;">
                    <button class="jebanyPrzyciskWPierdolonejOffCanvieW" style="">ZAMÓW SPRZĄTANIE</button></a></div>
                  </div>
                  </div>
                </div>
              </div>
        </section>
        </div>
        <div class="col-6 col-md-4 col-lg-4 justify-content-mid" style="margin-bottom: 2%;word-wrap: break-word;">
        <section id="pranieSamochodow">
          <header>
            <h1 class="semanticHeader" style="display: none;">PRANIE TAPICERKI SAMOCHODOWEJ</h1>
          </header>
          <div class="img-thumbnail text-center" id="pojemnikCzymSieZajmujemy">
            <img class="czymSieZajmujemyImg" src="img/pts.jpg" class="rounded mx-auto d-block" style="width: 100%;height:auto">
            <p class="czymSieZajmujemyH3">PRANIE TAPICERKI SAMOCHODOWEJ</p>
            <div class="text-center">
              <button class="btn btn-primary" id="czymSieZajmujemyButtons" style="background-color:#208BE3;" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasWithBothOptionsS" aria-controls="offcanvasWithBothOptionsS">
                ZOBACZ SZCZEGÓŁY
              </button>
              </div>
<div class="offcanvas offcanvas-start" style="background-color: #444444;width:90%;color:white;font-family: 'Bebas Neue', cursive;" data-bs-scroll="true" tabindex="-1" id="offcanvasWithBothOptionsS" aria-labelledby="offcanvasWithBothOptionsLabel">
 
  <div class="text-end" style="background-color:#208BE3;">
    <p class="offcanvas-title" id="offcanvasWithBothOptionsLabel" style="float:left;" ><p style="float: left;text-align:center;font-size:1.2rem;margin-left:41%;padding-top:2px;">PRANIE TAPICERKI SAMOCHODOWEJ</p><button type="button" style="" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </p>
  </div>
  <div class="offcanvas-body" style="overflow-wrap: break-word;">

    <div class="row" style="height: 600px;">
      <div class="col-12 col-lg-6" style="margin-top: 1%;">
        <iframe width="100%" height="415" src="https://www.youtube.com/embed/siw9LZFem4c" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

      </div>
      <div class="col-12 col-lg-6" style="color:white;">
        <div class="paragrafPTS" style="text-align: center;" ><p>W samochodzie spędzamy bardzo dużo czasu, a plamy są nieuniknione. Zajmiemy się twoją tapicerką samochodową kompleksowo.</p></div>
        <div class="accordion" id="accordionExampleS" style="background-color: #444444;">
          <div class="accordion-item" style="background-color: #444444;">
            <h2 class="accordion-header" style="text-align: center;" id="headingOneS">
              <button class="accordion-button" style="" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOneS" aria-expanded="true" aria-controls="collapseOneS">
              <div class="text-center">Jak przebiega czyszczenie ?</div>
              </button>
            </h2>
            <div id="collapseOneS" class="accordion-collapse collapse show" aria-labelledby="headingOneS" data-bs-parent="#accordionExampleS">
              <div class="accordion-body">
                <div class="row" style="padding: 0 !important;font-size:0.8rem;">
                  <div class="col-12 col-lg-6" style="padding: 0 !important;margin: 0 !important;">
                <ul style="list-style-type: none;padding: 0 !important;font-family: 'Montserrat', sans-serif;word-break: break-all;">
                  <li style="font-size: 1rem;margin-bottom:2%; font-family: 'Bebas Neue', cursive;"><i class="icon-ok"style="color:green;visibility:hidden;"></i>Jak przebiega czyszczenie ?</li>
                  <li><i class="icon-ok"style=""></i>Odkurzanie foteli</li>
                  <li><i class="icon-ok"></i>Rozpoznanie materiału</li>
                  <li><i class="icon-ok"></i>Nałożenie środków do rozpuszczenia brudu</li>
                  <li><i class="icon-ok"></i>Odplamianie</li>
                  <li><i class="icon-ok"></i>Płukanie i neutralizacja chemii</li>
                  <li><i class="icon-ok"></i>Suszenie</li>
                </ul>
              </div>
              <div class="col-12 col-lg-6" style="padding: 0 !important;margin: 0 !important;">
                <ul style="list-style-type: none;padding:0 !important;font-family: 'Montserrat', sans-serif;word-break: break-all;">
                  <li style="font-size: 1rem;margin-bottom:2%;margin-left:-3%;font-family: 'Bebas Neue', cursive;"><i class="icon-ok"style="color:green;visibility:hidden;"></i>Warto wiedzieć !</li>
                  <li><i class="icon-ok"></i>W samochodzie spędzamy średnio godzinę dziennie, ale nie sprzątamy go tak często jak naszego domu.</li>
                  <li><i class="icon-ok"></i>Dbając o samochód podnosimy jego wartość.</li>
                  <li><i class="icon-ok"></i>W samochodzie znajduje się więcej bakterii, niż w publicznej toalecie!</li>
                </ul>
              </div>
              </div>
              </div>
            </div>
          </div>
          <div class="accordion-item">
            <h2 class="accordion-header" id="headingTwoS">
              <button class="accordion-button collapsed"   type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwoS" aria-expanded="false" aria-controls="collapseTwoS">
                Pytanie i odpowiedzi
              </button>
            </h2>
            <div id="collapseTwoS" class="accordion-collapse collapse" aria-labelledby="headingTwoS" data-bs-parent="#accordionExampleS">
              <div class="accordion-body">
                <div class="containerPS">
                   <p class="paragrafContainerPS">1. Jak długo będzie wysychać mój samochód?</p>
                <div class="overlayPS" >
                <div class="textPS"><p class="paragraftextPS">1. W przypadku prania samochodu tapicerka wysycha do kilku godzin. Proces można przyspieszyć włączając ciepły nawiew i klimatyzację. Suchym i czystym autem będziesz mógł się cieszyć po 2 godzinach.</p></div>
                </div>
                </div>
                <div class="containerPS">
                  <p class="paragrafContainerPS">2.	Mam alcantarę w samochodzie. Czy można ją prać?</p>
                <div class="overlayPS" >
                <div class="textPS"><p class="paragraftextPS">2. Dla uzyskania jak najlepszych efektów wręcz ZALECAMY pranie alcantary. Przy użyciu odpowiednich środków można uzyskać lepszy efekt niż w przypadku prania ręcznego.</p></div>
                </div>
                </div>
                <div class="containerPS">
                  <p class="paragrafContainerPS">3.	Mam pół-skórzane fotele, czy można je wyprać?</p>
                <div class="overlayPS" >
                <div class="textPS"><p class="paragraftextPS">3. Tak, używamy środków, które nie niszczą skóry i pranie naszą metodą jest bezpieczne dla tego typu foteli.</p></div>
                </div>
                </div>
                <div class="containerPS" style="height: 65px;">
                  <p class="paragrafContainerPS">4. Co jest wymagane, aby usługa się odbyła?</p>
                <div class="overlayPS" >
                <div class="textPS"><p class="paragraftextPS">4. Najbardziej wymagany jest dostęp do prądu i cepłej wody. Resztą zajmiemy się sami :)</p></div>
                </div>
                </div>
                <div class="containerPS" style="height:115px;">
                  <p class="paragrafContainerPS">4.	Czy czyścicie skórzane fotele?</p>
                <div class="overlayPS" >
                <div class="textPS"><p class="paragraftextPS">5. Tak, zajmujemy się również czyszczeniem i zabezpieczaniem skórzanych tapicerek.</p></div>
                </div>
                </div>
               </div>
              </div>
            </div>
          <div class="accordion-item">
            <h2 class="accordion-header" id="headingThreeS">
              <button class="accordion-button collapsed"   type="button" data-bs-toggle="collapse" data-bs-target="#collapseThreeS" aria-expanded="false" aria-controls="collapseThreeS">
                Realizacje
              </button>
            </h2>
            <div id="collapseThreeS" class="accordion-collapse collapse" aria-labelledby="headingThreeS" data-bs-parent="#accordionExampleS">
              <div class="accordion-body">
                <div class="rowLS">
                  <div class="columnLS">
                    <img src="img/czystakanapadwa.jpg" style="width:100%" onclick="openModalS();currentSlideS(1)" class="hover-shadowLS cursorLS">
                  </div>
                  <div class="columnLS">
                    <img src="img/czystakanapa.jpg" style="width:100%" onclick="openModalS();currentSlideS(2)" class="hover-shadowLS cursorLS">
                  </div>
                  <div class="columnLS">
                    <img src="img/czystakanapadwa.jpg" style="width:100%" onclick="openModalS();currentSlideS(3)" class="hover-shadowLS cursorLS">
                  </div>
                  <div class="columnLS">
                    <img src="img/czystakanapa.jpg" style="width:100%" onclick="openModalS();currentSlideS(4)" class="hover-shadowLS cursorLS">
                  </div>
                </div>
                
                <div id="myModalLS" class="modalLS">
                  <span class="closeLS cursorLS" onclick="closeModalS()">&times;</span>
                  <div class="modal-contentLS">
                
                    <div class="mySlidesLS">
                      <div class="numbertextLS">1 / 4</div>
                      <img src="img/czystakanapadwa.jpg" style="width:100%;height:50%;">
                    </div>
                
                   <div class="mySlidesLS">
                      <div class="numbertextLS">2 / 4</div>
                      <img src="img/czystakanapa.jpg" style="width:100%;height:auto;">
                    </div>
                
                    <div class="mySlidesLS">
                      <div class="numbertextLS">3 / 4</div>
                      <img src="img/czystakanapadwa.jpg" style="width:100%;height:auto;">
                    </div>
                    
                   <div class="mySlidesLS">
                      <div class="numbertextLS">4 / 4</div>
                      <img src="img/czystakanapa.jpg" style="width:100%;height:auto;">
                    </div>
                    
                    <a class="prevLS" onclick="plusSlidesS(-1)">&#10094;</a>
                    <a class="nextLS" onclick="plusSlidesS(1)">&#10095;</a>
                
                    <div class="caption-containerLS">
                      <p id="captionLS"></p>
                    </div>
                    <div class="columnLS">
                      <img class="demoLS cursorLS" src="img/czystakanapadwa.jpg" style="width:50%" onclick="currentSlideS(1)" alt="Brudna Kanapa Przed">
                    </div>
                    <div class="columnLS">
                      <img class="demoLS cursorLS" src="img/czystakanapa.jpg" style="width:50%" onclick="currentSlideS(2)" alt="Czysta Kanapa Po">
                    </div>
                    <div class="columnLS">
                      <img class="demoLS cursorLS" src="img/czystakanapadwa.jpg" style="width:50%" onclick="currentSlideS(3)" alt="Brudne Cokolwiek">
                    </div>
                    <div class="columnLS">
                      <img class="demoLS cursorLS" src="img/czystakanapa.jpg" style="width:50%" onclick="currentSlideS(4)" alt="Czyste Cokolwiek">
                    </div>
                  </div>
                </div>
              </div>
            </div>
              </div>
          <div class="accordion-item">
            <h2 class="accordion-header" id="headingFourS">
              <button class="accordion-button collapsed"   type="button" data-bs-toggle="collapse" data-bs-target="#collapseFourS" aria-expanded="false" aria-controls="collapseFourS">
                Cennik
              </button>
            </h2>
            <div id="collapseFourS" class="accordion-collapse collapse" aria-labelledby="headingFourS" data-bs-parent="#accordionExampleS">
              <div class="accordion-body">
                <div class="table-responsive-sm" style="background-color: #444444;">
                  <table class="table"  style="background-color:#444444;line-height:6px ;height: 100%;font-size:0.8rem;color:white;">
                    <thead>
                    </thead>
                    <tbody>
                      <tr>
                        <td>Pranie foteli przód i tył</td>
                        <td><strong>Od 150zł</strong></td>
                      </tr>
                      <tr>
                        <td>Wykładzina</td>
                        <td><strong>Od 50zł</strong></td>
                      </tr>
                      <tr>
                        <td>Tapicerka drzwi</td>
                        <td><strong>Od 20zł/szt.</strong></td>
                      </tr>
                      <tr>
                        <td>Podsufitka</td>
                        <td><strong>Od 50zł</strong></td>
                      </tr>
                      <tr>
                        <td>Czyszczenie plastików</td>
                        <td><strong>Od 50zł</strong></td>
                      </tr>
                      <tr>
                        <td>Polerowanie reflektorów</td>
                        <td><strong>Od 120zł</strong></td>
                      </tr>
                      <tr>
                        <td>Czyszczenie skóry</td>
                        <td style="word-wrap: break-word;"><strong>INDYWIDUALNIE</strong></td>
                      </tr>
                    </tr>
                </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="text-center"><a href="#kontakt" style="text-decoration: none;color:white;">
      <button class="jebanyPrzyciskWPierdolonejOffCanvieS" style="">ZAMÓW SPRZĄTANIE</button></a></div>
    </div>
    </div>
</div>
            </div>
</section>
</div>
        
      <div class="col-6 col-md-4 col-lg-4 justify-content-mid" style="margin-bottom: 2%;">
        <section id="ozonowanie">
          <header>
            <h1 class="semanticHeader" style="display: none;">OZONOWANIE</h1>
          </header>
          <div class="img-thumbnail text-center" id="pojemnikCzymSieZajmujemy">
            <img  src="img/detailingsamochodowy.jpg" class="rounded mx-auto d-block" style="width: 100%;height:auto">
    
                <p class="czymSieZajmujemyH3">OZONOWANIE</p>
                <div class="text-center">
                  <button class="btn btn-primary" id="czymSieZajmujemyButtons" style="background-color:#208BE3;" type="button"data-bs-toggle="offcanvas" data-bs-target="#offcanvasWithBothOptionsO" aria-controls="offcanvasWithBothOptionsO">
                    ZOBACZ SZCZEGÓŁY
                  </button>
                  </div>
                  <div class="offcanvas offcanvas-end" style="background-color: #444444;width:90%;color:white;font-family: 'Bebas Neue', cursive;" data-bs-scroll="true" tabindex="-1" id="offcanvasWithBothOptionsO" aria-labelledby="offcanvasWithBothOptionsLabel">
                    <div class="text-end" style="background-color:#208BE3;">
                      <p class="offcanvas-title" id="offcanvasWithBothOptionsLabel" style="float:left;font-size:1rem;"><button type="button" style="width:10%;" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button><p style="float: left;text-align:center;font-size:1.2rem;margin-left:45%;padding-top:2px;">OZONOWANIE</p>
                      </p>
                    </div>
                  <div class="offcanvas-body" style="word-wrap: break-word;">
                           
                    <div class="row" style="height: 600px;">
                      <div class="col-12 col-lg-6" style="margin-top: 1%;">
                        <iframe width="100%" height="415" src="https://www.youtube.com/embed/siw9LZFem4c" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            
                      </div>
                      <div class="col-12 col-lg-6" style="color:white;">
                        <div class="paragrafPTO" style="text-align: center;" ><p>Dezynfekcja pojazdów i pomieszczeń ozonem to bardzo dobre rozwiązanie w celu pozbycia się wirusów, grzybów, bakterii. Nasze metody są bezinwazyjne i skuteczne.</p></div>
                        <div class="accordion" id="accordionExampleO" style="background-color: #444444;">
                          <div class="accordion-item" style="background-color: #444444;">
                            <h2 class="accordion-header" style="text-align: center;" id="headingOneO">
                              <button class="accordion-button" style="" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOneO" aria-expanded="true" aria-controls="collapseOneO">
                              <div class="text-center">Jak przebiega czyszczenie ?</div>
                              </button>
                            </h2>
                            <div id="collapseOneO" class="accordion-collapse collapse show" aria-labelledby="headingOneO" data-bs-parent="#accordionExampleO">
                              <div class="accordion-body">
                                <div class="row" style="padding: 0 !important;font-size:0.8rem;">
                                  <div class="col-12 col-lg-6" style="padding: 0 !important;margin: 0 !important;">
                                <ul style="list-style-type: none;padding: 0 !important;font-family: 'Montserrat', sans-serif;word-break: break-all;">
                                  <li style="font-size: 1rem;margin-bottom:2%; font-family: 'Bebas Neue', cursive;"><i class="icon-ok"style="color:green;visibility:hidden;"></i>Jak przebiega czyszczenie ?</li>
                                  <li><i class="icon-ok"style=""></i>Wyniesienie roślin z pomieszczeń</li>
                                  <li><i class="icon-ok"></i>Ustawienie ozonatora na odpowiednio długi cykl</li>
                                  <li><i class="icon-ok"></i>Po zakończonych cyklach następuje rozkład ozonu</li>
                                  <li><i class="icon-ok"></i>Wietrzenie pomieszczenia</li>
                                  
                                </ul>
                              </div>
                              <div class="col-12 col-lg-6" style="padding: 0 !important;margin: 0 !important;">
                                <ul style="list-style-type: none;padding:0 !important;font-family: 'Montserrat', sans-serif;word-break: break-all;">
                                  <li style="font-size: 1rem;margin-bottom:2%;margin-left:-3%;font-family: 'Bebas Neue', cursive;"><i class="icon-ok"style="color:green;visibility:hidden;"></i>Warto wiedzieć !</li>
                                  <li><i class="icon-ok"></i>Ozonowanie zabija wirusy, bakterie i grzyby oraz neutralizuje nieprzyjemne zapachy</li>
                                  <li><i class="icon-ok"></i>Jest świetną, bezinwazyjną metodą na dezynfekcję pomieszczeń, przedszkoli, szkół, sal konferencyjnych</li>
                                  <li><i class="icon-ok"></i>Ozonowanie zabija również wirusa SarS-CoV19</li>
                                </ul>
                              </div>
                              </div>
                              </div>
                            </div>
                          </div>
                          <div class="accordion-item">
                            <h2 class="accordion-header" id="headingTwoO">
                              <button class="accordion-button collapsed"   type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwoO" aria-expanded="false" aria-controls="collapseTwoO">
                                Pytanie i odpowiedzi
                              </button>
                            </h2>
                            <div id="collapseTwoO" class="accordion-collapse collapse" aria-labelledby="headingTwoO" data-bs-parent="#accordionExampleO">
                              <div class="accordion-body">
                                <div class="containerPO">
                                   <p class="paragrafContainerPO">1.	Jak mam się przygotować do ozonowania?</p>
                                <div class="overlayPO" >
                                <div class="textPO"><p class="paragraftextPO">1. Przede wszystkim prosimy o opuszczenie pomieszczenia przez ludzi oraz zwierzęta. Obligatoryjne jest wyniesienie kwiatów i roślin.</p></div>
                                </div>
                                </div>
                                <div class="containerPO">
                                  <p class="paragrafContainerPO">2.	Czy ozonowanie zabija koronawirusa?</p>
                                <div class="overlayPO" >
                                <div class="textPO"><p class="paragraftextPO">2. Tak, ozonator zabija wirusy, bakterie i grzyby, działa dezynfekująco na całe pomieszczenie. Gdy dany teren jest skażony pomaga w jego dezynfekcji.</p></div>
                                </div>
                                </div>
                                <div class="containerPO">
                                  <p class="paragrafContainerPO">3.	Czy można ozonować samochody ?</p>
                                <div class="overlayPO" >
                                <div class="textPO"><p class="paragraftextPO">3. Tak, ozonujemy cały system klimatyzacji oraz wnętrza samochodu. Pomoże w pozbyciu się zapachu papierosów, pleśni i innych brzydkich zapachów.</p></div>
                                </div>
                                </div>
                                <div class="containerPO" style="height: 65px;">
                                  <p class="paragrafContainerPO">4.	Jak długo trwa ozonowanie ?</p>
                                <div class="overlayPO" >
                                <div class="textPO"><p class="paragraftextPO">4. Ozonowanie może trwać od kilkunastu minut do kilku godzin. Pomieszczenie później przez drugie tyle powinno być wietrzone.</p></div>
                                </div>
                                </div>
                               </div>
                              </div>
                            </div>
                          <div class="accordion-item">
                            <h2 class="accordion-header" id="headingThreeO">
                              <button class="accordion-button collapsed"   type="button" data-bs-toggle="collapse" data-bs-target="#collapseThreeO" aria-expanded="false" aria-controls="collapseThreeO">
                                Realizacje
                              </button>
                            </h2>
                            <div id="collapseThreeO" class="accordion-collapse collapse" aria-labelledby="headingThreeO" data-bs-parent="#accordionExampleO">
                              <div class="accordion-body">
                                <div class="rowLO">
                                  <div class="columnLO">
                                    <img src="img/ozonowanie.jpg" style="width:100%" onclick="openModalO();currentSlideO(1)" class="hover-shadowLO cursorLO">
                                  </div>
                                  <div class="columnLO">
                                    <img src="img/czystakanapa.jpg" style="width:100%" onclick="openModalO();currentSlideO(2)" class="hover-shadowLO cursorLO">
                                  </div>
                                  <div class="columnLO">
                                    <img src="img/ozonowanie.jpg" style="width:100%" onclick="openModalO();currentSlideO(3)" class="hover-shadowLO cursorLO">
                                  </div>
                                  <div class="columnLO">
                                    <img src="img/czystakanapa.jpg" style="width:100%" onclick="openModalO();currentSlideO(4)" class="hover-shadowLO cursorLO">
                                  </div>
                                </div>
                                
                                <div id="myModalLO" class="modalLO">
                                  <span class="closeLO cursorLO" onclick="closeModalO()">&times;</span>
                                  <div class="modal-contentLO">
                                
                                    <div class="mySlidesLO">
                                      <div class="numbertextLO">1 / 4</div>
                                      <img src="img/ozonowanie.jpg" style="width:100%;height:50%;">
                                    </div>
                                
                                   <div class="mySlidesLO">
                                      <div class="numbertextLO">2 / 4</div>
                                      <img src="img/czystakanapa.jpg" style="width:100%;height:auto;">
                                    </div>
                                
                                    <div class="mySlidesLO">
                                      <div class="numbertextLO">3 / 4</div>
                                      <img src="img/ozonowanie.jpg" style="width:100%;height:auto;">
                                    </div>
                                    
                                   <div class="mySlidesLO">
                                      <div class="numbertextLO">4 / 4</div>
                                      <img src="img/czystakanapa.jpg" style="width:100%;height:auto;">
                                    </div>
                                    
                                    <a class="prevLO" onclick="plusSlidesO(-1)">&#10094;</a>
                                    <a class="nextLO" onclick="plusSlidesO(1)">&#10095;</a>
                                
                                    <div class="caption-containerLO">
                                      <p id="captionLO"></p>
                                    </div>
                                    <div class="columnLO">
                                      <img class="demoLO cursorLO" src="img/ozonowanie.jpg" style="width:50%" onclick="currentSlideO(1)" alt="Brudna Kanapa Przed">
                                    </div>
                                    <div class="columnLO">
                                      <img class="demoLO cursorLO" src="img/czystakanapa.jpg" style="width:50%" onclick="currentSlideO(2)" alt="Czysta Kanapa Po">
                                    </div>
                                    <div class="columnLO">
                                      <img class="demoLO cursorLO" src="img/ozonowanie.jpg" style="width:50%" onclick="currentSlideO(3)" alt="Brudne Cokolwiek">
                                    </div>
                                    <div class="columnLO">
                                      <img class="demoLO cursorLO" src="img/czystakanapa.jpg" style="width:50%" onclick="currentSlideO(4)" alt="Czyste Cokolwiek">
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                              </div>
                          <div class="accordion-item">
                            <h2 class="accordion-header" id="headingFourO">
                              <button class="accordion-button collapsed"   type="button" data-bs-toggle="collapse" data-bs-target="#collapseFourO" aria-expanded="false" aria-controls="collapseFourO">
                                Cennik
                              </button>
                            </h2>
                            <div id="collapseFourO" class="accordion-collapse collapse" aria-labelledby="headingFourO" data-bs-parent="#accordionExampleO">
                              <div class="accordion-body">
                                <div class="table-responsive-sm" style="background-color: #444444;">
                                  <table class="table"  style="background-color:#444444;line-height:6px ;height: 100%;font-size:0.8rem;color:white;">
                                    <thead>
                                    </thead>
                                    <tbody>
                                      <tr>
                                        <td>Pranie kanapy lub sofy 2/3-osobowej</td>
                                        <td ><strong>Od 120zł</strong></td>
                                      </tr></br>
                                      <tr>
                                        <td >Narożnik mały (suma boków do 4,5m)</td>
                                        <td><strong>Od 120zł</strong></td>
                                      </tr>
                                      <tr>
                                        <td>Narożnik duży (suma boków pow. 4,5m)</td>
                                        <td><strong>Od 160zł</strong></td>
                                      </tr>
                                      <tr>
                                        <td>Narożnik w kształcie U</td>
                                        <td><strong>Od 180zł</strong></td>
                                      </tr>
                                      <tr>
                                        <td>Poduszka tapicerowana</td>
                                        <td><strong>Od 10zł</strong></td>
                                      </tr>
                                      <tr>
                                        <td>Fotel</td>
                                        <td><strong>Od 25zł</strong></td>
                                      </tr>
                                      <tr>
                                        <td>Krzesło/Krzesło tapicerowane</td>
                                        <td><strong>Od 10zł</strong></td>
                                      </tr>
                                      <tr>
                                        <td>Pufy</td>
                                        <td><strong>Od 20zł</strong></td>
                                      </tr>
                                      <tr>
                                        <td>Materac jednostronnie/dwustronnie</td>
                                        <td><strong>Od 80zł</strong></td>
                                      </tr>
                                      <tr>
                                        <td>Gondola/Wózek/Fotelik samochodowy</td>
                                        <td><strong>Od 50zł</strong></td>
                                      </tr>
                                    </tbody>
                                  </table>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="text-center"><a href="#kontakt" style="text-decoration: none;color:white;">
                      <button class="jebanyPrzyciskWPierdolonejOffCanvieO" style="">ZAMÓW SPRZĄTANIE</button></a></div>
                    </div>
                    </div>
                  </div>
            </div>
        
        </section>
 </div>
 <div class="col-6 col-md-4 col-lg-4 justify-content-mid" style="margin-bottom: 2%;">
        <section id="sprzatanieBiur">
          <header>
            <h1 class="semanticHeader" style="display: none;">SPRZĄTANIE MIESZKAŃ I BIUR</h1>
          </header>
          <div class="img-thumbnail text-center" id="pojemnikCzymSieZajmujemy">
            <img class="czymSieZajmujemyImg" src="img/sprzataniedomowimieszkan.jpg" class="rounded mx-auto d-block" style="width: 100%;height:auto">

            <p class="czymSieZajmujemyH3">SPRZATANIE MIESZKAN I BIUR</p>
            <div class="text-center">
              <button class="btn btn-primary" id="czymSieZajmujemyButtons" style="background-color:#208BE3;" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasWithBothOptionsB" aria-controls="offcanvasWithBothOptionsB">
                ZOBACZ SZCZEGÓŁY
              </button>
              </div>
<div class="offcanvas offcanvas-start" style="background-color: #444444;width:90%;color:white;font-family: 'Bebas Neue', cursive;" data-bs-scroll="true" tabindex="-1" id="offcanvasWithBothOptionsB" aria-labelledby="offcanvasWithBothOptionsLabel">
 
  <div class="text-end" style="background-color:#208BE3;"><p class="offcanvas-title" id="offcanvasWithBothOptionsLabel" style="float:left;"><p style="float: left;text-align:center;font-size:1.2rem;margin-left:45%;padding-top:2px;">SPRZĄTANIE MIESZKAŃ I BIUR</p><button type="button" style="" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </p>
  </div>
  <div class="offcanvas-body" style="overflow-wrap: break-word;">

    <div class="row " style="height: 600px;">
      <div class="col-12 col-lg-6" style="margin-top: 1%;">
        <iframe width="100%" height="415" src="https://www.youtube.com/embed/siw9LZFem4c" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

      </div>
      <div class="col-12 col-lg-6" style="color:white;">
        <div class="paragrafPTMB" style="text-align: center;" ><p>Kompleksowo zajmiemy się twoim domem lub biurem. Posiadamy szeroką ofertę indywidualną oraz dla firm.</p></div>
        <div class="accordion" id="accordionExampleB" style="background-color: #444444;">
          <div class="accordion-item" style="background-color: #444444;">
            <h2 class="accordion-header" style="text-align: center;" id="headingOneB">
              <button class="accordion-button" style="" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOneB" aria-expanded="true" aria-controls="collapseOneB">
              <div class="text-center">Jak przebiega czyszczenie ?</div>
              </button>
            </h2>
            <div id="collapseOneB" class="accordion-collapse collapse show" aria-labelledby="headingOneB" data-bs-parent="#accordionExampleB">
              <div class="accordion-body">
                <div class="row" style="padding: 0 !important;font-size:0.8rem;">
                  <div class="col-12 col-lg-6" style="padding: 0 !important;margin: 0 !important;">
                <ul style="list-style-type: none;padding: 0 !important;font-family: 'Montserrat', sans-serif;word-break: break-all;">
                  <li style="font-size: 1rem;margin-bottom:2%; font-family: 'Bebas Neue', cursive;"><i class="icon-ok"style="color:green;visibility:hidden;"></i>Jak przebiega czyszczenie ?</li>
                  <li><i class="icon-ok"style=""></i>Sprzątanie oferujemy w dwóch wariantach. Podstawowe(cykliczne) oraz doczyszczanie(kompleksowe).</li>
                  <li><i class="icon-ok"></i>Jeżeli potrzebujesz więcej informacji, napisz do nas po darmową wycenę.</li>
          
                </ul>
              </div>
              <div class="col-12 col-lg-6" style="padding: 0 !important;margin: 0 !important;">
                <ul style="list-style-type: none;padding:0 !important;font-family: 'Montserrat', sans-serif;word-break: break-all;">
                  <li style="font-size: 1rem;margin-bottom:2%;margin-left:-3%;font-family: 'Bebas Neue', cursive;"><i class="icon-ok"style="color:green;visibility:hidden;"></i>Warto wiedzieć !</li>
                  <li><i class="icon-ok"></i>Czyste otoczenie to lepsze myślenie!</li>
                  <li><i class="icon-ok"></i>! Zadbaj o otoczenie pracowników w swoim biurze, a wykażą się jeszcze lepiej.</li>
                  <li><i class="icon-ok"></i>Czyste mieszkanie spowoduje, że skupisz się na swoich priorytetach, a nie na sprzątaniu.</li>
                  <li><i class="icon-ok"></i>Będziesz mniej chorować! Twój dom potrafi być skupiskiem bakterii i wirusów, kiedy o to nie zadbasz.</li>
                </ul>
              </div>
              </div>
              </div>
            </div>
          </div>
          <div class="accordion-item">
            <h2 class="accordion-header" id="headingTwoB">
              <button class="accordion-button collapsed"   type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwoB" aria-expanded="false" aria-controls="collapseTwoB">
                Pytanie i odpowiedzi
              </button>
            </h2>
            <div id="collapseTwoB" class="accordion-collapse collapse" aria-labelledby="headingTwoB" data-bs-parent="#accordionExampleB">
              <div class="accordion-body">
                <div class="containerPB">
                   <p class="paragrafContainerPB">1.	Na co się składa sprzątanie podstawowe?</p>
                <div class="overlayPB" >
                <div class="textPB"><p class="paragraftextPB">1. Sprzątanie podstawowe to między innymi: Odkurzanie i mycie podłóg w pomieszczeniach, czyszczenie blatów w kuchni oraz naczyń, mycie toalety. W celu ustalenie reszty szczegółów napisz do nas. Do każdego klienta podchodzimy indywidualnie.</p></div>
                </div>
                </div>
                <div class="containerPB">
                  <p class="paragrafContainerPB">2.	Na co składa się sprzątanie kompleksowe?</p>
                <div class="overlayPB" >
                <div class="textPB"><p class="paragraftextPB">2. Sprzątanie kompleksowe obejmuje cały pakiet sprzątania podstawowego oraz doczyszczanie powierzchni, mebli, szafek, piekarnika i wszystkich zakamarków.</p></div>
                </div>
                </div>
                <div class="containerPB">
                  <p class="paragrafContainerPB">3.	Jak wyceniana jest usługa?</p>
                <div class="overlayPB" >
                <div class="textPB"><p class="paragraftextPB">3. ? Sprzątanie mieszkań jest wyceniane przez naszych fachowców na miejscu. Po wstępną wycenę należy przesłać zdjęcia pomieszczeń i podanie szczegółów.</p></div>
                </div>
                </div>
                <div class="containerPB" style="height: 65px;">
                  <p class="paragrafContainerPB">4.	Czy mogę zamówić sprzątanie co tydzień?</p>
                <div class="overlayPB" >
                <div class="textPB"><p class="paragraftextPB">4. Tak, w przypadku sprzątania cyklicznego usługa ma znacznie niższą cenę, niż kompleksowe sprzątanie.</p></div>
                </div>
                </div>
               </div>
              </div>
            </div>
          <div class="accordion-item">
            <h2 class="accordion-header" id="headingThreeB">
              <button class="accordion-button collapsed"   type="button" data-bs-toggle="collapse" data-bs-target="#collapseThreeB" aria-expanded="false" aria-controls="collapseThreeB">
                Realizacje
              </button>
            </h2>
            <div id="collapseThreeB" class="accordion-collapse collapse" aria-labelledby="headingThreeB" data-bs-parent="#accordionExampleB">
              <div class="accordion-body">
                <div class="rowLB">
                  <div class="columnLB">
                    <img src="img/czystakanapadwa.jpg" style="width:100%" onclick="openModalB();currentSlideB(1)" class="hover-shadowLB cursorLB">
                  </div>
                  <div class="columnLB">
                    <img src="img/czystakanapa.jpg" style="width:100%" onclick="openModalB();currentSlideB(2)" class="hover-shadowLB cursorLB">
                  </div>
                  <div class="columnLB">
                    <img src="img/czystakanapadwa.jpg" style="width:100%" onclick="openModalB();currentSlideB(3)" class="hover-shadowLB cursorLB">
                  </div>
                  <div class="columnLB">
                    <img src="img/czystakanapa.jpg" style="width:100%" onclick="openModalB();currentSlideB(4)" class="hover-shadowLB cursorLB">
                  </div>
                </div>
                
                <div id="myModalLB" class="modalLB">
                  <span class="closeLB cursorLB" onclick="closeModalB()">&times;</span>
                  <div class="modal-contentLB">
                
                    <div class="mySlidesLB">
                      <div class="numbertextLB">1 / 4</div>
                      <img src="img/czystakanapadwa.jpg" style="width:100%;height:50%;">
                    </div>
                
                   <div class="mySlidesLB">
                      <div class="numbertextLB">2 / 4</div>
                      <img src="img/czystakanapa.jpg" style="width:100%;height:auto;">
                    </div>
                
                    <div class="mySlidesLB">
                      <div class="numbertextLB">3 / 4</div>
                      <img src="img/czystakanapadwa.jpg" style="width:100%;height:auto;">
                    </div>
                    
                   <div class="mySlidesLB">
                      <div class="numbertextLB">4 / 4</div>
                      <img src="img/czystakanapa.jpg" style="width:100%;height:auto;">
                    </div>
                    
                    <a class="prevLB" onclick="plusSlidesB(-1)">&#10094;</a>
                    <a class="nextLB" onclick="plusSlidesB(1)">&#10095;</a>
                
                    <div class="caption-containerLB">
                      <p id="captionLB"></p>
                    </div>
                    <div class="columnLB">
                      <img class="demoLB cursorLB" src="img/czystakanapadwa.jpg" style="width:50%" onclick="currentSlideB(1)" alt="Brudna Kanapa Przed">
                    </div>
                    <div class="columnLB">
                      <img class="demoLB cursorLB" src="img/czystakanapa.jpg" style="width:50%" onclick="currentSlideB(2)" alt="Czysta Kanapa Po">
                    </div>
                    <div class="columnLB">
                      <img class="demoLB cursorLB" src="img/czystakanapadwa.jpg" style="width:50%" onclick="currentSlideB(3)" alt="Brudne Cokolwiek">
                    </div>
                    <div class="columnLB">
                      <img class="demoLB cursorLB" src="img/czystakanapa.jpg" style="width:50%" onclick="currentSlideB(4)" alt="Czyste Cokolwiek">
                    </div>
                  </div>
                </div>
              </div>
            </div>
              </div>
          <div class="accordion-item">
            <h2 class="accordion-header" id="headingFourB">
              <button class="accordion-button collapsed"   type="button" data-bs-toggle="collapse" data-bs-target="#collapseFourB" aria-expanded="false" aria-controls="collapseFourB">
                Cennik
              </button>
            </h2>
            <div id="collapseFourB" class="accordion-collapse collapse" aria-labelledby="headingFourB" data-bs-parent="#accordionExampleB">
              <div class="accordion-body">
                <div class="table-responsive-sm" style="background-color: #444444;">
                  <table class="table"  style="background-color:#444444;line-height:6px ;height: 100%;font-size:0.8rem;color:white;">
                    <thead>
                    </thead>
                    <tbody>
                      <tr>
                        <td>Pranie kanapy lub sofy 2/3-osobowej</td>
                        <td ><strong>Od 120zł</strong></td>
                      </tr></br>
                      <tr>
                        <td >Narożnik mały (suma boków do 4,5m)</td>
                        <td><strong>Od 120zł</strong></td>
                      </tr>
                      <tr>
                        <td>Narożnik duży (suma boków pow. 4,5m)</td>
                        <td><strong>Od 160zł</strong></td>
                      </tr>
                      <tr>
                        <td>Narożnik w kształcie U</td>
                        <td><strong>Od 180zł</strong></td>
                      </tr>
                      <tr>
                        <td>Poduszka tapicerowana</td>
                        <td><strong>Od 10zł</strong></td>
                      </tr>
                      <tr>
                        <td>Fotel</td>
                        <td><strong>Od 25zł</strong></td>
                      </tr>
                      <tr>
                        <td>Krzesło/Krzesło tapicerowane</td>
                        <td><strong>Od 10zł</strong></td>
                      </tr>
                      <tr>
                        <td>Pufy</td>
                        <td><strong>Od 20zł</strong></td>
                      </tr>
                      <tr>
                        <td>Materac jednostronnie/dwustronnie</td>
                        <td><strong>Od 80zł</strong></td>
                      </tr>
                      <tr>
                        <td>Gondola/Wózek/Fotelik samochodowy</td>
                        <td><strong>Od 50zł</strong></td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="text-center"><a href="#kontakt" style="text-decoration: none;color:white;">
      <button class="jebanyPrzyciskWPierdolonejOffCanvieB" style="">ZAMÓW SPRZĄTANIE</button></a></div>
    </div>
    </div>
</div>
            </div>
        </section>
 </div>
 <div class="col-6 col-md-4 col-lg-4 justify-content-mid" style="margin-bottom: 2%;word-wrap: break-word;">
        <section id="detailingSamochodowy">
          <header>
            <h1 class="semanticHeader" style="display: none;">DETAILING SAMOCHODOWY</h1>
          </header>
        <div class="img-thumbnail" id="pojemnikCzymSieZajmujemy">
          <img class="czymSieZajmujemyImg" src="img/detailingsamochodowy.jpg" style="width: 100%;height:auto">
          <h2 class="semanticHeader" style="display: none;">Przejdź do serwisu</h2>
          <p class="czymSieZajmujemyH3">DETAILING SAMOCHODOWY</p>
          <div class="text-center">
            <a style="text-decoration: none;" href="https://pranietapicerkiwroclaw.pl"><button class="btn btn-primary" id="czymSieZajmujemyButtons" style="background-color:#208BE3;" type="button">
              Przejdź do serwisu
              </button></a>
              </div>
      </section>
 </div>
      </div>
    </section>
    </div>
 
    <div class="container">
      <section>
      <header>
        <h1 class="mainHeading" style="text-align: center;font-weight:lighter;">DLACZEGO <span style="font-family: 'Bebas Neue', cursive;">MY ?</span></h1>
        <div class="col-2 col-xl-2 mainBorder" style="border-bottom: 4px solid #208BE3;"></div>
      </header>
      <div class="row" id="rowDlaczegoMy">
<div class="col-6 col-md-4 col-lg-4 justify-content-mid" id="dlaczegoMyKafelki">
    <section>
      <div class="flip-card">
        <div class="flip-card-inner">
          <div class="flip-card-front">
            <img src="img/iczaloga.png" class="img-fluid" alt="Avatar" style="width: 100%;height:auto;">
          </div>
          <div class="flip-card-back">
         <header>
            <h1 class="flipH5">Wykwalifikowana Załoga</h1> 
          <p class="flipP">Nasi pracownicy posiadają wieloletnie doświadczenie w sprzątaniu. Posiadamy kadrę, która jest odpowiednio wyszkolona.</p> 
        </header>
        </div>
        </div>
      </div>
    </section>
        </div>

<div class="col-6 col-md-4 col-lg-4 justify-content-mid" id="dlaczegoMyKafelki">
    <section>
      <div class="flip-card">
        <div class="flip-card-inner">
          <div class="flip-card-front">
            <img src="img/icdetergent.png" class="img-fluid" alt="Avatar" style="width: 100%;height:auto;">
          </div>
          <div class="flip-card-back">
            <header>
            <h1 class="flipH5">Profesjonalne detergenty</h1> 
        
            <p class="flipP">Korzystamy tylko z chemii przeznaczonej do zadań profesjonalnych. Odpowiednio dobieramy produkty do czyszczenia, które posiadają atesty i certyfikaty.</p> 
          </header>
          </div>
        </div>
      </div>
    </section>
        </div>
<div class="col-6 col-md-4 col-lg-4 justify-content-mid" id="dlaczegoMyKafelki">
    <section>
      <div class="flip-card">
        <div class="flip-card-inner">
          <div class="flip-card-front">
            <img src="img/ichome.png" class="img-fluid" alt="Avatar" style="width: 100%;height:auto;">
          </div>
          <div class="flip-card-back">
            <header>
            <h1 class="flipH5">Kompleksowa oferta</h1> 
         
            <p class="flipP">Nasz szeroki wybór usług jest odpowiednio dostosowany do indywidualnych potrzeb</p> 
            </header>
          </div>
        </div>
      </div>
    </section>
        </div>
<div class="col-6 col-md-4 col-lg-4 justify-content-mid" id="dlaczegoMyKafelki">
    <section>
      <div class="flip-card">
        <div class="flip-card-inner">
          <div class="flip-card-front">
            <img src="img/icoc.png" class="img-fluid" alt="Avatar" style="width: 100%;height:auto;">
          </div>
          <div class="flip-card-back">
            <header>
            <h1 class="flipH5">Ubezpieczenie OC</h1> 
          
            <p class="flipP">Nasza firma posiada ubezpieczenie OC. Nasi klienci i ich rzeczy są również chronione podczas naszej pracy. Nie martw się o zdarzenia losowe.</p> 
            </header>
          </div>
        </div>
      </div>
    </section>
        </div>
<div class="col-6 col-md-4 col-lg-4 justify-content-mid" id="dlaczegoMyKafelki">
    <section>
      <div class="flip-card">
        <div class="flip-card-inner">
          <div class="flip-card-front">
            <img src="img/ickartakred.png" class="img-fluid" alt="Avatar" style="width: 100%;height:auto;">
          </div>
          <div class="flip-card-back">
            <header>
            <h1 class="flipH5">Płatność Kartą</h1>
        
            <p class="flipP">Nie musisz wychodzić z domu, żeby zapłacić za naszą usługę. Zrobisz to u naszego pracownika.</p> 
          </header>
          </div>
        </div>
      </div>
    </section>
        </div>
<div class="col-6 col-md-4 col-lg-4 justify-content-mid" id="dlaczegoMyKafelki">
    <section>
      <div class="flip-card">
        <div class="flip-card-inner">
          <div class="flip-card-front">
            <img src="img/icsamochod.png" class="img-fluid" alt="Avatar" style="width: 100%;height:auto;">
          </div>
          <div class="flip-card-back">
            <header>
            <h1 class="flipH5">Dojazd do klienta</h1>
       
            <p class="flipP">W obrębie miasta dojeżdżamy za darmo. Nie musisz się martwić o dodatkowe koszta.</p> 
          </header>
          </div>
        </div>
      </div>
    </section>
        </div>
      </div>
  </section>
    </div>

    <div class="container" style="margin-top: 2%;">
      <section>
        <header>
          <h1 class="mainHeading" style="text-align: center;font-weight:lighter;">CO MÓWIĄ O NAS <span style="font-family: 'Bebas Neue', cursive;">KLIENCI?</span></h1>
          <div class="col-2 col-xl-2 mainBorder" style="border-bottom: 4px solid #208BE3;"></div>
        </header>
 
        <section><h1 class="semanticHeader" style="display: none;">OPINIE</h1></section>
      </section>
</div>
<div class="container" style="margin-top:2%;">
  <div style="height:70px" id="oferta"></div>
  <header>
       <h1 class="mainHeading" style="text-align: center;font-weight:lighter;">NASZA <span style="font-family: 'Bebas Neue', cursive;">OFERTA</span></h1>
       <div class="col-2 col-xl-2 mainBorder" style="border-bottom: 4px solid #208BE3;"></div>
  </header>
  <div class="row row-justify-content-mid-center" style="padding: 0 !important;color:white;margin-top:2%;">
    <div class="col-6" style="padding: 0 !important;">
    <section>
      <div class="containerLeft">
        <img src="img/indywidualna.jpg" alt="Avatar" class="imageLeft">
        <div class="centered">
    <header>
          <h1 style="font-weight: light;font-size:2rem;">OFERTA <span style="font-weight: bold;">INDYWIDUALNA</span></h1>
        </div>
    </header>
        <div class="overlayLeft" style="word-break: break-all;">
          <div class="textLeft" style="word-wrap:break-word;word-break: break-all;"><a href="#ofertaIndyHeader" class="linkIndywidualna" style="color: white;word-wrap:break-word;"><p style="font-weight: bolder;font-size:2rem;word-wrap:break-word;">OFERTA INDYWIDUALNA</p></a></div>
        </div>
      </div></section></div>
      <div class="col-6" style="padding: 0 !important;">
<section>  <div class="containerRight">
  <img src="img/dlafirm.jpg" alt="Avatar" class="imageRight">
  <div class="centered">
  <header>
    <h1 style="font-size: 2rem;">OFERTA DLA <span style="font-weight: bold;">FIRM</span></h1>
  </header>
  </div>
  <div class="overlayRight">
    <div class="textRight"><a href="#ofertaDlaFirmHeader" class="linkIndywidualna" style="color: white;"><p style="font-size: 2rem;">OFERTA DLA FIRM</p></a></div>
  </div>
</div></section></div> </div></div>
<div class="container">
  <div style="height:95px;" id="ofertaIndyHeader"></div>
  <p class="ofertaH3" style="text-align: center;font-size:1.5rem;">OFERTA <span style="font-family: 'Bebas Neue', cursive;">INDYWIDUALNA</span></p>
  <div class="col-2 col-xl-2 mainBorder" style="border-bottom: 4px solid #208BE3;"></div>
  <div class="row" style="margin-top: 2%;">
    <div class="col-12 col-xl-6">
      <p class="ofertaIndyP"><span class="pogrbOfertaIndyP">NCLEAN</span> to firma sprzątająca, zrzeszająca pracowników z wieloletnim doświadczeniem w sprzątaniu powierzchni. Specjalizujemy się w <span class="pogrbOfertaIndyP">praniu tapicerek oraz dywanów, sprzątaniu domów i ozonowaniu pomieszczeń. </span>Dla klientów indywidualnych posiadamy 
        szerokie spektrum usług, dostosowanych do ich potrzeb. 
        Usługi wykonujemy na terenie dolnego śląska.</p>
        <p class="ofertaIndyPOL">Jeżeli potrzebujesz:</p>
          <ul>
            <li class="ofertaIndyLi">wyprać meble lub dywan w swoim domu,</li>
            <li class="ofertaIndyLi">umyć okna w swoim mieszkaniu,</li>
            <li class="ofertaIndyLi">wyczyścić swoj samochód,</li>
            <li class="ofertaIndyLi">pozbyć się bakterii i grzybów z pomieszczeń,</li>
            <li class="ofertaIndyLi">kompleksowo wyczyścić mieszkanie,</li>
            <li class="ofertaIndyLi">posprzątać po remoncie,</li>
          </ul>
        <p class="ofertaIndyPOL">to umów się z nami telefonicznie lub poprzez formularz kontaktowy na stronie. Wykonamy szczegółową wycenę tego samego dnia.</p>
        <div class="text-center" style="margin-bottom: 2%;">
        <a href="#kontakt" style="text-decoration: none;color:white;">  <button class="ofertaIndyButt">ZAMÓW SPRZĄTANIE</button></a>
    </div>
    </div>
     <div class="d-none d-xl-block col-xl-6">
      <div class="parent" style="position: relative;top:0;left:0;">
        <img class="ofertaIndyImgThree" src="img/ofertindywiThree.jpg"style="width: 50%; position: relative;
        top: 0;
        left: 42%;">
    <img class="ofertaIndyImgOne" src="img/ofertindywiOne.jpg" style="width: 50%; position: absolute;
    top: 15%;
    left: 0px;
    border: 10px solid white;">
    <img class="ofertaIndyImgTwo" src="img/ofertindywiTwo.jpg"style="width: 50%; position: absolute;
    top: 55%;
    left: 35%;
    border: 10px solid white;">
    </div>
    </div>
  </div>
  <div style="height:95px;" id="ofertaDlaFirmHeader"></div>
  <p class="ofertaH3" style="text-align: center;font-size:1.5rem;">OFERTA DLA <span style="font-family: 'Bebas Neue', cursive;">FIRM</span></p>
  <div class="col-2 col-xl-2 mainBorder" style="border-bottom: 4px solid #208BE3;"></div>

  <div class="row" style="margin-top: 2%;">
    <div class="d-none d-xl-block col-xl-6">
      <div class="parent" style="position: relative;top:0;left:0;">
        <img class="ofertaFirmImgOne" src="img/ofertfirmOne.jpg" style="width: 80%; position: relative;
        top: 15%;
        left: 0px;
        border: 10px solid white;">
        <img class="ofertaFirmImgTwo" src="img/ofertfirmTwo.jpg"style="width: 50%; position: absolute;
        top: 70%;
        left: 35%;border:10px solid white;">
    </div>
    </div>
    <div class="col-12 col-xl-6">
     <p class="ofertaFirmaP"><span class="pogrbOfertaFirmP">Kompleksowe sprzątanie </span>zapewniamy również<span class="pogrbOfertaFirmP"> klientom biznesowym.</span> Wycena naszych usług dla klientów biznesowych jest indywidualna. Naszą ofertę kierujemy do<span class="pogrbOfertaFirmP"> właścicieli biur, przedszkoli, kin, teatrów, zajmiemy się twoją flotą samochodów firmowych. </span></p>
     <p class="ofertaFirmaPOL">Jeżeli potrzebujesz:</p>
     <ul>
       <li class="ofertaFirmaLi">cyklicznego sprzątania biura</li>
       <li class="ofertaFirmaLi">prania wykładziny w sali konferencyjnej</li>
       <li class="ofertaFirmaLi">czyszczenie dywanu w przedszkolu</li>
       <li class="ofertaFirmaLi">obsługę floty pojazdów</li>
       <li class="ofertaFirmaLi">sprzątania po remoncie</li>
     </ul>
     <p class="ofertaFirmaPOL">to umów się z nami telefonicznie lub poprzez formularz kontaktowy na stronie. Wykonamy szczegółową wycenę tego samego dnia.</p>
    <div class="text-center">
      <a href="#kontakt" style="text-decoration: none;color:white;"><button class="ofertaFirmButt">ZAMÓW SPRZĄTANIE</button></a>
    </div>
    </div>
  </div>
</div>

<div class="container" style="margin-top: 2%;">
  
  <header>
    <h1 class="mainHeading" style="text-align: center;">PYTANIA I <span style="font-family: 'Bebas Neue', cursive;">ODPOWIEDZI</span></h1>
    <div class="col-2 col-xl-2 mainBorder" style="border-bottom: 4px solid #208BE3;"></div>
</header>
<section><h1 class="semanticHeader" style="display: none;">PYTANIA</h1></section>

</div>

<div style="height:70px" id="kontakt"></div>
<div class="container-fluid" style="background-image: url('img/formularzlapki1.jpg'); height:100%; background-repeat:no-repeat;background-size:cover;background-position:center;margin-top:2%;font-size:0.9rem;">
  
  <div class="container" style="color: white;">
    <div class="row">
      <div class="col" style="margin-top: 4%;">
        
<header>
        <h1 style="font-family: 'Bebas Neue', cursive;font-size:5rem;">ZAMÓW</br>USŁUGĘ</h1>
        <p style="font-family: 'Bebas Neue', cursive;font-size:1.5rem;">Wyślij formularz skontaktujemy się z Tobą w sprawie wyceny sprzątania</p>
</header>
        <img src="img/Logo.png" style="width: 100%;">
      </div>
      <div class="col" style="margin-top: 4%;">
        <section><h1 class="semanticHeader" style="display: none;">FORMULARZ KONTAKTOWY</h1>
          <?php 
          echo $alert;
          ?>
        <form class="contact"  method="POST" enctype="multipart/form-data">
          <div class="form-group" id="divFormularz" style="margin-top: 5%;margin-bottom:4%;">
            <input type="text" name="name" class="form-control" id="exampleFormControlInput1" placeholder="Imię i nazwisko lub nazwa firmy" required>
          </div>
          <div class="form-group" id="divFormularz">
            <input type="email" name="email" class="form-control" id="exampleFormControlInput1" placeholder="Twój E-mail" required>
          </div>
          <div class="form-group" id="divFormularz">
            <input type="text" name="telephone" class="form-control" id="exampleFormControlInput1" placeholder="Twój numer telefonu" required>
            <label for="custom-checkbox" style="font-weight: bolder;" >Rodzaj oferty:</label>
          </div>
          <div class="custom-control custom-checkbox" id="divFormularz" aria-required="true">
            <input  class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="Oferta Indywidualna">
            <label class="custom-control-label"  for="inlineRadio1">Oferta Indywidualna</label>
          <div class="custom-control custom-checkbox" id="divFormularz">
            <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="Oferta dla Firm">
            <label class="custom-control-label" for="inlineRadio2">Oferta dla firm</label>
            </div>
            <div class="custom-control custom-checkbox" id="divFormularz">
            <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio3" value="Inne zapytanie">
            <label class="custom-control-label" for="inlineRadio3">Inne zapytanie</label>
            </div>
            <div class="form-group" id="divFormularz">
              <textarea class="form-control" name="message" id="exampleFormControlTextarea1" rows="6" placeholder="Treść wiadomości" required></textarea>
              <div class="text-center" style="margin-top: 5%;">
              <button type="submit" name="submit" class="btn btn-primary my-1" style="font-family: 'Bebas Neue', cursive;width:50%;">Wyślij</button>
            </div>
            </div>
          </div>
        </form>
        </section>
      
      </div>
    </div>
  </div>
</div>
    </section>
  </div>
    
<footer>
  <div class="container-fluid" style="background-color: rgb(69, 73, 77);color:white;">
   <section><h1 class="semanticHeader" style="display: none;">Stopka</h1>
    <div class="container" style="color: white;">
      <div class="row">
      <div class="col-12 col-lg-6 col-xl-4" style="margin-top:2%;">
      <section> <h1 class="semanticHeader" style="display: none;">Dane Kontaktowe</h1>
        <p class="footerHeading" style="font-size:1.2rem;">Kontakt</p>
        <table class="table table-sm" style="color: white;border:none;border:rgb(69, 73, 77);">
          <thead>
          </thead>
          <tbody style="border:rgb(69, 73, 77);">
            <tr style="border:rgb(69, 73, 77);">
              <td><i class="icon-phone"></i></td>
              <td><a class="footerLinks" href="tel:+48573379778">+48 573 379 778</a></td>
            </tr>
            <tr>
              <td><i class="icon-mail-alt"></i></td>
              <td><a class="footerLinks" href="mailto:nicodetailingwroclaw@gmail.com">nicodetailingwroclaw@gmail.com</a></td>
            </tr>
            <tr>
              <td><i class="icon-location"></i></td>
              <td><a class="footerLinks" href="https://www.google.com/maps/place/NicoDetailing+-+pranie+tapicerki,+polerowanie+reflektorów,+czyszczenie+samochodu/@51.0752071,17.0031156,15z/data=!4m5!3m4!1s0x0:0x674197298b2c8d2f!8m2!3d51.0752071!4d17.0031156">Ul. Juliana Tuwima 5</br>53-021 Wrocław</td></a>
            </tr>
          </tbody>
        </table>
      </section>
      </div>
      <div class="col-12 col-lg-6 col-xl-4" style="margin-top:2%;">
  <section><h1 class="semanticHeader" style="display: none;">MEDIA SPOŁECZNOŚCIOWE</h1>
    <p class="footerHeading" style="font-size:1.2rem;">Odwiedź nas</p>
    <div class="row">
      <div class="col-6">
    <a class="linkFooterSpol" href="https://www.facebook.com/groups/249646959887986"><i class="icon-facebook" style="font-size:45px;"></i></a>
      </div>
      <div class="col-6">
        <a class="linkFooterSpolInsta" href="https://www.instagram.com/nicodetailingwroclaw/?fbclid=IwAR0vxBzsta8pdcSq4sKkDzuqMKaIBCA6ICV0xRJcJ265QsJyy-ggnt_zZwQ"><i class="icon-instagram" style="font-size:45px;"></i></a>
      </div>
    </div>
  </section>
  </div>
  <div class="col-12 col-lg-12 col-xl-4" style="margin-top:2%;">
<section><h1 class="semanticHeader" style="display: none;">RODZAJ USŁUG</h1>
    <p class="footerHeading" style="font-size:1.2rem;" >Usługi</p>
    <table class="table table-sm" style="color: white;border:rgb(69, 73, 77);">
      <thead>
      </thead>
      <tbody style="border:rgb(69, 73, 77);">
        <tr>
          <td><a class="footerLinks" href="#pranieMeblowe">Pranie tapicerki meblowej</a></td>
          <td><a class="footerLinks" href="#ozonowanie">Ozonowanie</a></td>
        </tr>
        <tr>
          <td><a class="footerLinks" href="#pranieSamochodow">Pranie tapicerki samochodowej</a></td>
          <td><a class="footerLinks" href="#pranieDywanow">Pranie dywanów i wykładzin</a></td>
        </tr>
        <tr>
          <td><a class="footerLinks" href="#sprzatanieBiur">Sprzątanie mieszkań i biur</a></td>
          <td><a class="footerLinks" href="#detailingSamochodowy">Detailing samochodowy</a></td>
        </tr>
      </tbody>
    </table>
  </section>
  </div>
      </div>
    </div>
  </section>
  </div>
</footer>
</div>
<button onclick="topFunction()" id="toTopButton" title="Go to top">☝️</button>

<!--SCROLL REVEAL-->
<script>
  ScrollReveal().reveal('.mainHeading', {delay:500, duration: 500, origin:'top',distance:'15px',easing:'linear' });
  ScrollReveal().reveal('.mainBorder', {origin: 'left',delay:500, duration:1000, distance : '120px',easing:'linear',});
  ScrollReveal().reveal('.czymSieZajmujemyP', { duration: 3000 });
  ScrollReveal().reveal('.czymSieZajmujemyH3', { duration: 700,origin:'top',distance:'25px',easing:'linear',delay:250 });
  ScrollReveal().reveal('.czymSieZajmujemyImg',{delay:500,origin:'top',distance:'25px',easing:'linear',duration:500});
  ScrollReveal().reveal('.btn', { duration: 500,origin:'top',distance:'25px',easing:'linear',delay:700});
  ScrollReveal().reveal('.flip-card', { duration:500,delay:700,origin:'top',distance:'70px',easing:'linear'});
  ScrollReveal().reveal('.centered', {duration:3000});
  ScrollReveal().reveal('.ofertaH3', { duration: 2000 });
  ScrollReveal().reveal('.ofertaIndyP',{duration:1000,origin:'left',delay:700,distance:'75px',easing:'linear'});
  ScrollReveal().reveal('.ofertaIndyPOL',{duration:1000,origin:'left',delay:700,distance:'75px',easing:'linear'});
  ScrollReveal().reveal('.ofertaIndyImgThree',{origin:'right',delay:500,duration:1000,distance:'55px',easing:'linear'});
  ScrollReveal().reveal('.ofertaIndyImgTwo',{origin:'left',delay:700,duration:1000,distance:'55px',easing:'linear'});
  ScrollReveal().reveal('.ofertaIndyImgOne',{origin:'bottom',delay:900,duration:1000,distance:'55px',easing:'linear'});
  ScrollReveal().reveal('.ofertaIndyLi',{duration:1000,origin:'left',delay:700,distance:'75px',easing:'linear'});
  ScrollReveal().reveal('.ofertaIndyButt',{origin:'left',delay:700,duration:1000,distance:'150px',easing:'linear'});
  ScrollReveal().reveal('.ofertaFirmaP',{duration:1000,origin:'right',delay:700,distance:'75px',easing:'linear'});
  ScrollReveal().reveal('.ofertaFirmaPOL',{duration:1000,origin:'right',delay:700,distance:'75px',easing:'linear'});
  ScrollReveal().reveal('.ofertaFirmImgOne',{origin:'left',delay:700,duration:1000,distance:'55px',easing:'linear'});
  ScrollReveal().reveal('.ofertaFirmImgTwo',{origin:'right',delay:500,duration:1000,distance:'55px',easing:'linear'});
  ScrollReveal().reveal('.ofertaFirmaLi',{duration:1000,origin:'right',delay:700,distance:'75px',easing:'linear'});
  ScrollReveal().reveal('.ofertaFirmButt',{origin:'right',delay:700,duration:1000,distance:'150px',easing:'linear'});
</script>
<!--BOOTSTRAP BUNDLE-->
<script src="js/bootstrap.bundle.min.js" >
</script>
<!--SKRYPT FORMULARZ-->
<script type="text/javascript">

  if(window.history.replaceState){
    window.history.replaceState(null, null, window.location.href);
  };
</script>
<!--SKRYPT NAVBAR-->
<script type="text/javascript">
  var nav = document.querySelector('nav');

  window.addEventListener('scroll', function () {
    if (window.pageYOffset > 600) {
      nav.classList.add('bg-navlist');
    } else {
      nav.classList.remove('bg-navlist');
    }
  });
</script>
<!--SKRYPTY GALERIA OFFCANVY-->
<script>

  function openModal() {
    document.getElementById("myModalL").style.display = "block";
  }
  function closeModal() {
    document.getElementById("myModalL").style.display = "none";
  }
  var slideIndex = 1;
  showSlides(slideIndex);
  function plusSlides(n) {
    showSlides(slideIndex += n);
  }
  function currentSlide(n) {
    showSlides(slideIndex = n);
  }
  function showSlides(n) {
    var i;
    var slides = document.getElementsByClassName("mySlidesL");
    var dots = document.getElementsByClassName("demoL");
    var captionText = document.getElementById("captionL");
    if (n > slides.length) {slideIndex = 1}
    if (n < 1) {slideIndex = slides.length}
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndex-1].style.display = "block";
    dots[slideIndex-1].className += " active";
    captionText.innerHTML = dots[slideIndex-1].alt;
  }
 

  function openModalW() {
    document.getElementById("myModalLW").style.display = "block";
  }
  function closeModalW() {
    document.getElementById("myModalLW").style.display = "none";
  }
  var slideIndexW = 1;
  showSlidesW(slideIndexW);
  function plusSlidesW(n) {
    showSlidesW(slideIndexW += n);
  }
  function currentSlideW(n) {
    showSlidesW(slideIndexW = n);
  }
  function showSlidesW(n) {
    var i;
    var slides = document.getElementsByClassName("mySlidesLW");
    var dots = document.getElementsByClassName("demoLW");
    var captionText = document.getElementById("captionLW");
    if (n > slides.length) {slideIndexW = 1}
    if (n < 1) {slideIndexW = slides.length}
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndexW-1].style.display = "block";
    dots[slideIndexW-1].className += " active";
    captionText.innerHTML = dots[slideIndexW-1].alt;
  }
  
  function openModalS() {
    document.getElementById("myModalLS").style.display = "block";
  }
  function closeModalS() {
    document.getElementById("myModalLS").style.display = "none";
  }
  var slideIndexS = 1;
  showSlidesS(slideIndexS);
  function plusSlidesS(n) {
    showSlidesS(slideIndexS += n);
  }
  function currentSlideS(n) {
    showSlidesS(slideIndexS = n);
  }
  function showSlidesS(n) {
    var i;
    var slides = document.getElementsByClassName("mySlidesLS");
    var dots = document.getElementsByClassName("demoLS");
    var captionText = document.getElementById("captionLS");
    if (n > slides.length) {slideIndexS = 1}
    if (n < 1) {slideIndexS = slides.length}
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndexS-1].style.display = "block";
    dots[slideIndexS-1].className += " active";
    captionText.innerHTML = dots[slideIndexS-1].alt;
  }
  
  function openModalO() {
    document.getElementById("myModalLO").style.display = "block";
  }
  function closeModalO() {
    document.getElementById("myModalLO").style.display = "none";
  }
  var slideIndexO = 1;
  showSlidesO(slideIndexO);
  function plusSlidesO(n) {
    showSlidesO(slideIndexO += n);
  }
  function currentSlideO(n) {
    showSlidesO(slideIndexO = n);
  }
  function showSlidesO(n) {
    var i;
    var slides = document.getElementsByClassName("mySlidesLO");
    var dots = document.getElementsByClassName("demoLO");
    var captionText = document.getElementById("captionLO");
    if (n > slides.length) {slideIndexO = 1}
    if (n < 1) {slideIndexO = slides.length}
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndexO-1].style.display = "block";
    dots[slideIndexO-1].className += " active";
    captionText.innerHTML = dots[slideIndexO-1].alt;
  }
  
  function openModalB() {
    document.getElementById("myModalLB").style.display = "block";
  }
  function closeModalB() {
    document.getElementById("myModalLB").style.display = "none";
  }
  var slideIndexB = 1;
  showSlidesB(slideIndexB);
  function plusSlidesB(n) {
    showSlidesB(slideIndexB += n);
  }
  function currentSlideB(n) {
    showSlidesB(slideIndexB = n);
  }
  function showSlidesB(n) {
    var i;
    var slides = document.getElementsByClassName("mySlidesLB");
    var dots = document.getElementsByClassName("demoLB");
    var captionText = document.getElementById("captionLB");
    if (n > slides.length) {slideIndexB = 1}
    if (n < 1) {slideIndexB = slides.length}
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndexB-1].style.display = "block";
    dots[slideIndexB-1].className += " active";
    captionText.innerHTML = dots[slideIndexB-1].alt;
  }
</script>
<!--TO TOP BUTTON-->
<script type="text/javascript">
    //Get the button
    var mybutton = document.getElementById("toTopButton");
    
    // When the user scrolls down 20px from the top of the document, show the button
    window.onscroll = function() {scrollFunction()};
    
    function scrollFunction() {
      if (document.body.scrollTop > 600 || document.documentElement.scrollTop > 600) {
        mybutton.style.display = "block";
      } else {
        mybutton.style.display = "none";
      }
    }
    
    // When the user clicks on the button, scroll to the top of the document
    function topFunction() {
      document.body.scrollTop = 0;
      document.documentElement.scrollTop = 0;
    }
    
</script>














<!--PRELOADER-->
<script>
  var loader = document.getElementById("preloader");

  window.addEventListener("load", function() {
    loader.style.display = "none";
  })

</script>

</body>
</html>