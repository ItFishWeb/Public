<?php 
use PHPMailer\PHPMailer\PHPMailer;

require_once 'src/Exception.php';
require_once 'src/PHPMailer.php';
require_once 'src/SMTP.php';

$mail = new PHPMailer(true);
$mail->SMTPDebug=0;

$alert = '';

if(isset($_POST['submit'])){
    
    $name = $_POST['name'];
    $email = $_POST['email'];
    $telephone = $_POST['telephone'];
    $inlineRadioOptions = $_POST['inlineRadioOptions'];
    $message = $_POST['message'];
    try{
        $mail->isSMTP();
        $mail->Host = 'mail.cba.pl';
        $mail->SMTPAuth = true;
        $mail->Username = 'testnicoclean@cleantestnico.cba.pl';
        $mail->Password = 'Test12@';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->SMTPAutoTLS = false;
        $mail->Port = '587';

        $mail->setFrom('testnicoclean@cleantestnico.cba.pl');
        $mail->addAddress('kamilkarp22@gmail.com');

        $mail->isHTML(true);
        $mail->Subject = 'Otrzymano wiadomość (Strona kontaktowa)';
        $mail->Body = "<h3>Imie : $name <br>Email: $email <br>Telefon: $telephone<br>Rodzaj Zapytania: $inlineRadioOptions<br>Wiadomość: $message</h3>";


        $mail->send();
        $alert = '</br><div class="alert" role="alert">
        <h4 class="alert-heading">Dziękujemy! :)</h4>
        <p>Wiadomość została wysłana! Obserwuj swoją skrzynkę e-mail.</p>
      </div>';
    } catch (Exception $e){
        $alert = '</br><div class="alert alert-danger"  role="alert">
       Ups.. coś poszło nie tak :('.$e->getMessage().'
      </div>';


    }

}
?>